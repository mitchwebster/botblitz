from .stats_db import import_def_seasonal_data

df = import_def_seasonal_data(year=2023)
print(df)