# botblitz

## Getting Started

1. First, clone this repo  
2. Run `make launch-simulator`  
3. Begin coding your first Python fantasy football bot!

## Engine Commands

`make clean` - removes generated proto classes

`make gen` - generates proto classes from proto

`make test` - runs tests

`make run-draft` - run draft
