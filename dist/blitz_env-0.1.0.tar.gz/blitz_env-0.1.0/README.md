# botblitz

## Agent Runner Commands

`make clean` - removes generated proto classes

`make gen` - generates proto classes from proto

`make test` - runs tests

`make run-engine` - run engine
